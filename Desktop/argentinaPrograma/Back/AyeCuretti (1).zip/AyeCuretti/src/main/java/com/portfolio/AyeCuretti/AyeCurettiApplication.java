package com.portfolio.AyeCuretti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AyeCurettiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AyeCurettiApplication.class, args);
	}

}
