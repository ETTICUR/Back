package com.portfolio.AyeCuretti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyeCurettiApplicationTests {

	@Test
	void contextLoads() {
	}

}
